$("#Code").click(function (e) { 
    e.preventDefault();
    $("#Code").fadeOut();    
});

$("#menuButton").click(function (e) { 
    e.preventDefault();
    $("#menuButton").toggle();
  
    $("#menuButton").fadeOut();
    $("#nav").show();
    $("#nav").animate({
        width: '7%',
        height: '30%'
    }, 1000)


});


tent =
    {
        name: "Tent",
        price: 350,
        productId: 123

    },
 cooler = {
       name: "Cooler",
    price: 250,
    productId: 124  
},
   
    
binoculars = {
    name: "Binoculars",
        price: 75,
        productId: 125
}
        
  
var submit = document.getElementById("submit")
var form = document.getElementById("gearForm")
var confirmationElement = document.getElementById("confirmation")
var codeInput = document.getElementById("codeEnter")

var tentCheck = document.getElementById("tentItem")
var coolerCheck = document.getElementById("coolerItem")
var binoCheck = document.getElementById("binocularsItem")

var totalResult = document.getElementById("shopTotal")

function checkBox(){
    if (tentCheck.checked){
        totalResult = totalResult + 6  
    }
}

form.addEventListener("submit", function (e) { 
    e.preventDefault()
    checkBox()
    if (codeInput.value === "20off"){
      confirmationElement.innerText = "Your Order Has Been Submitted and Code Has Been Applied"  

     } else{
        confirmationElement.innerText = "Your Order Has Been Submitted, No Code Was Used"
    }

      
    
 })


 (function() {                             // Lives in an IIFE
    var $imgs = $('.image');          // Get the images
    var $search = $('#storySearch');      // Get the input element
    var cache = [];                         // Create an array called cache
  
    $imgs.each(function() {                 // For each image
      cache.push({                          // Add an object to the cache array
        element: this,                      // This image
        text: this.alt.trim().toLowerCase() // Its alt text (lowercase trimmed)
      });
    });
  
    function filter() {                     // Declare filter() function
      var query = this.value.trim().toLowerCase();  // Get the query
      cache.forEach(function(img) {         // For each entry in cache pass image 
        var index = 0;                      // Set index to 0
  
        if (query) {                        // If there is some query text
          index = img.text.indexOf(query);  // Find if query text is in there
        }
  
        img.element.style.display = index === -1 ? 'none' : '';  // Show / hide
      });
    }
  
    if ('oninput' in $search[0]) {          // If browser supports input event
      $search.on('input', filter);          // Use input event to call filter()
    } else {                                // Otherwise
      $search.on('keyup', filter);          // Use keyup event to call filter()
    }              
  
  }());





