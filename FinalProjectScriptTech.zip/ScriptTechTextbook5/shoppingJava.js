products = [
    {
        name: "Tent",
        price: 350,
        productId: 123

    },
    {
    name: "Cooler",
    price: 250,
    productId: 124
    },
    {
        name: "Binoculars",
        price: 75,
        productId: 125
    }

]

var submit = document.getElementById("submit")
var form = document.getElementById("gearForm")
var confirmationElement = document.getElementById("confirmation")
var codeInput = document.getElementById("codeEnter")

var tentCheck = document.getElementById("tentItem")
var coolerCheck = document.getElementById("coolerItem")
var binoCheck = document.getElementById("binocularsItem")

var totalResult = document.getElementById("shopTotal")

function checkBox(){
    if (tentCheck.checked){
        totalResult.innerText = 30
    }
}

form.addEventListener("submit", function (e) { 
    e.preventDefault()
    checkBox()
    if (codeInput.value === "20off"){
      confirmationElement.innerText = "Your Order Has Been Submitted and Code Has Been Applied"  

     } else{
        confirmationElement.innerText = "Your Order Has Been Submitted, No Code Was Used"
    }

      
    
 })